from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.home, name='home'),
    path('addCustomer/', views.addCustomer, name='addCustomer'),
    path('cat/', views.addCategory, name='addCategory'),
    path('brand/', views.addBrand, name='addBrand'),
    path('supply/', views.addSupplier, name='supplier'),
    path('product/', views.addProduct, name='products'),
    path('purch/', views.addPurchase, name='purchase'),
    path('manage/', views.manage, name='manage'),
    path('delete/<int:pk>', views.delete, name='delete'),
    path('deletep/<int:pk>', views.deleteproducts, name='delproducts'),
    path('deleteb/<int:pk>', views.deletebrand, name='delbrand'),
    path('deletec/<int:pk>', views.deletecategory, name='delcategory'),
    path('deletem/<int:pk>', views.deletemanage, name='delmanage'),
    path('deletepur/<int:pk>', views.deletepurchase, name='delpurchase'),
    path('deletes/<int:pk>', views.deletesupplier, name='delsupplier'),
    path('', views.login, name='login'),
    path('logout/', views.logout, name='logout'),
]