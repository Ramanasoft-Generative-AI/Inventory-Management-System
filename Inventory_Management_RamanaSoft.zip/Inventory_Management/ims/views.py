from django.shortcuts import render, redirect
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
from .models import Customer, Category, Brand, Supplier, Product, Purchase, Manage
from .forms import BrandForm, ProductForm, PurchaseForm, ManageForm
from django.contrib.auth.models import User
from django.contrib import auth
from django.contrib.auth.decorators import login_required
# Create your views here.


# function for add Customer in customer module
@login_required(login_url='login')
def home(request):
    product = Product.objects.all()
    purchase = Purchase.objects.all()
    for i in purchase:
        a = i.quantity
        print(a)
    display11 = Manage.objects.all()
    context = {'product':product,
               'purchase':purchase,
               'display11':display11,
               'a':a,
               }
    for i in purchase:
        a = i.quantity
        print(a)
    return render(request, 'home.html',context)

@login_required(login_url='login')
def addCustomer(request):
    cust = Customer.objects.all()

    if request.method == 'POST':
        name = request.POST['name']
        mobile = request.POST['mobile']
        balance = request.POST['balance']
        address = request.POST['address']

        data = Customer(name=name, mobile=mobile, balance=balance, address=address)
        data.save()
        return redirect('addCustomer')

    context = {'cust':cust}

    return render(request, 'customer.html', context)

def delete(requst, pk):
    delt = Customer.objects.get(id=pk)
    delt.delete()
    return redirect('addCustomer')

# function for add Category in Category module
@login_required(login_url='login')
def addCategory(request):
    cate = Category.objects.all()

    if request.method == 'POST':
        name = request.POST['name']
        data = Category(name=name)
        data.save()
        return redirect('addCategory')
    context = {'cate':cate}
    return render(request, 'category.html', context)

def deletecategory(request, pk):
    deltc =Category.objects.get(id=pk)
    deltc.delete()
    return redirect('addCategory')

@login_required(login_url='login')
def addBrand(request):
    form = BrandForm()
    brand = Brand.objects.all()

    if request.method == 'POST':
        form = BrandForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('addBrand')


    context = {'form':form, 'brand':brand}
    return render(request, 'brandList.html', context)

def deletebrand(request, pk):
    deltb = Brand.objects.get(id=pk)
    deltb.delete()
    return redirect('addBrand')

@login_required(login_url='login')
def addSupplier(request):
    supply = Supplier.objects.all()

    if request.method == 'POST':
        name = request.POST['name']
        mobile = request.POST['mobile']
        address = request.POST['address']
        data = Supplier(name=name, mobile=mobile, address=address)
        data.save()
        return redirect('supplier')
    context = {'supply':supply}
    return render(request, 'supplier.html', context)

def deletesupplier(request, pk):
    delts = Supplier.objects.get(id=pk)
    delts.delete()
    return redirect('supplier')

@login_required(login_url='login')
def addProduct(request):
    form = ProductForm()
    prod = Product.objects.all()

    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('products')

    context = {'form':form ,'prod': prod}
    return render(request, 'product.html', context)

def deleteproducts(request, pk):
    deltp = Product.objects.get(id=pk)
    deltp.delete()
    return redirect('products')

@login_required(login_url='login')
def addPurchase(request):
    form = PurchaseForm
    purc = Purchase.objects.all()

    if request.method == 'POST':
        form = PurchaseForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('purchase')

    context = {'form': form, 'purc': purc}
    return render(request, 'purchase.html', context)

def deletepurchase(request, pk):
    deltpur = Purchase.objects.get(id=pk)
    deltpur.delete()
    return redirect('purchase')

@login_required(login_url='login')
def manage(request):
    form = ManageForm()
    mana = Manage.objects.all()

    if request.method == 'POST':
        form = ManageForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('manage')

    context = {'mana': mana, 'form':form}
    return render(request, 'manage.html', context)

def deletemanage(request, pk):
    deltm = Manage.objects.get(id=pk)
    deltm.delete()
    return redirect('manage')

def login(request):
    if request.method == 'POST':  #(POST == POST)True
        username = request.POST['username']
        password = request.POST['password']

        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            print("Login Successfully")
            return redirect('addCustomer')
        else:
            print("You provide Invalid Details")
            return redirect('login')
    else:
        return render(request, 'login.html')

@login_required(login_url='login')
def logout(request):
    if request.method == 'POST':
        auth.logout(request)
        print("logged out from Website")
        return redirect('login')